package com.oshana.api.exception;

public class FileReaderException extends RuntimeException {
    public FileReaderException(Exception e) {
        super(e);
    }
}
