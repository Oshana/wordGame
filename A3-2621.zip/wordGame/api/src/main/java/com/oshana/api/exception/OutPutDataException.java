package com.oshana.api.exception;

public class OutPutDataException  extends  RuntimeException{
    public OutPutDataException(Exception e) {
        super(e);
    }
}
