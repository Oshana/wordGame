package com.oshana.api.util;

import java.io.IOException;

public interface LevelAssignLogicStrategy {
   void classifier(String words) throws IOException;
}
