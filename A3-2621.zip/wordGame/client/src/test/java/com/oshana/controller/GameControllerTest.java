package com.oshana.controller;

import org.junit.Test;

import static org.junit.Assert.*;

public class GameControllerTest {

    @Test
    public void start() {
    }
}