package com.oshana.dataSource;

import org.junit.Test;

import static org.junit.Assert.*;

public class DataSourceControllerTest {

    @Test
    public void wordBank() {
//        assertArrayEquals("Apple",);
    }
}