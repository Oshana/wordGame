package com.oshana.controller.attempts;

public interface AttemptsControllerInterface {
    int attemptsCount(int level);
}
