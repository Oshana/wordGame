package com.oshana.dataSource;

public enum DataSourceType {
    API_DATA
}
