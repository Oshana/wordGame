package com.oshana.controller;

public interface GameControllerInterface {
    void start(int levels) throws Exception;
}
