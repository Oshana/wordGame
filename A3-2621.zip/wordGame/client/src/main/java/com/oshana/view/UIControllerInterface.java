package com.oshana.view;

public interface UIControllerInterface {

    void printInNewLine(String message);

    void print(String message);

    void printChar(char message);

    char scan();
}
