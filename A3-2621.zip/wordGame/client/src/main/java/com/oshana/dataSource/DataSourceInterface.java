package com.oshana.dataSource;

public interface DataSourceInterface {
    char[] wordBank(int wordLevel) throws Exception;
}
