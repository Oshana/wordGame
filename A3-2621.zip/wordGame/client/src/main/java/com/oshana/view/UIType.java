package com.oshana.view;

public enum UIType {
    COMMAND_LINE
}
